# Scopus-Java-API
revisar los archivos .jar
falta declarar clase principal
